### Experiment No 1


### Outupt

![Output](exp_1.png)
