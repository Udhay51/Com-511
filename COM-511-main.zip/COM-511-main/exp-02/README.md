### Experiment No 2


### Outupt

![Output](exp_2.png)
