### Experiment No 3


### Outupt

![Output](exp_3.png)
